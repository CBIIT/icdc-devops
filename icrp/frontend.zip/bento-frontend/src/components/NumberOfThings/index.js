export { default } from './NumberOfThingsView';
