/* eslint-disable */

import React from 'react';
import { Footer } from 'bento-components';
import FooterData from '../../bento/globalFooterData.js';

// import nihLogo from '../../assets/header/icdc_nih_logo.svg';

const ICDCFooter = () => <><Footer data={FooterData} /></>;
export default ICDCFooter;
