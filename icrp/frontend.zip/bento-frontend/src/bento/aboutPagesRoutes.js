export default [
  '/bento',
  '/resources',
];
