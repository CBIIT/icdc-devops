import Easter from '../assets/header/headerGraphic.png';

// globalHeaderLogo image 468x100
// globalHeaderImage: image 2200x100
export default {
  globalHeaderLogo: 'https://raw.githubusercontent.com/CBIIT/bento-tools/master/src/components/assets/header/CTDC_Logo.svg',
  globalHeaderLogoLink: '/',
  globalHeaderLogoAltText: 'Bento Logo',
  globalHeaderImage: Easter,
};
