export default () => ({
  tableStyle: {
    maxWidth: '100%',
  },
});
